document.querySelectorAll('button').forEach(button => {
  button.addEventListener('click', () => {
    alert('Producto agregado al carrito');
  });
});
